# CampusMate AI — College Study Assistant

CampusMate AI is a responsive web application starter for college students. It provides an AI study tutor, smart notes, practice quizzes, exam planning, concept explanations and a research assistant.

## Important: GitHub vs live hosting

GitHub stores your source code and provides version control. It does not run this Node.js backend by itself. This project is configured so you can:
- Push the code to a GitHub repository.
- Connect that repository to Render to publish the complete website.
- Keep your OpenAI API key safely in Render environment variables (never in frontend code or GitHub).

A free Render service may sleep when inactive and take a little time to wake up.

## 1. Run on your computer

Requirements: Node.js 20+ and an OpenAI API key.

```bash
npm install
```

Copy `.env.example` to `.env`, then add your API key:

```env
OPENAI_API_KEY=your_api_key_here
OPENAI_MODEL=gpt-4.1-mini
PORT=3001
```

Start development:

```bash
npm run dev
```

Open the Vite URL printed in the terminal, usually `http://localhost:5173`.

## 2. Upload the project to GitHub

1. Sign in to GitHub and create a new empty repository named `campusmate-ai`.
2. Extract this ZIP and open the extracted folder in VS Code.
3. Open the VS Code terminal in the project folder.
4. Run these commands, replacing `YOUR-USERNAME` with your GitHub username:

```bash
git init
git add .
git commit -m "Initial CampusMate AI website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/campusmate-ai.git
git push -u origin main
```

Do not upload `.env`. It is excluded by `.gitignore`.

## 3. Publish the website using Render

1. Create/sign in to Render.
2. Choose **New** → **Blueprint** (or create a Web Service).
3. Connect your GitHub account and select the `campusmate-ai` repository.
4. Render detects `render.yaml` and configures the build and start commands.
5. In the service environment settings, add `OPENAI_API_KEY` with your own API key.
6. Deploy. Render will provide a public website address.

If creating a Web Service manually, use:
- Runtime: Node
- Build command: `npm install && npm run build`
- Start command: `npm start`
- Health check path: `/api/health`
- Environment variables: `OPENAI_API_KEY` and optionally `OPENAI_MODEL`

The frontend and backend are served by the same Node service, so the browser does not need a separate API URL.

## Features in this starter

- AI Study Tutor
- Smart Notes summariser
- Practice Quiz generator
- Exam Planner
- Concept Explainer
- Research Assistant with optional web search

## Project structure

```text
campusmate-ai/
├── .github/workflows/ci.yml
├── client/
│   ├── src.jsx
│   └── style.css
├── server/
│   └── index.js
├── .env.example
├── .gitignore
├── index.html
├── package.json
├── render.yaml
└── vite.config.js
```

## Security and limitations

- Keep API keys in server-side environment variables only. Never commit `.env`, API keys, or secrets.
- OpenAI API usage can incur charges; ChatGPT subscriptions and API billing are separate.
- This is an MVP starter, not yet a production-ready student information system.
- It currently does not include login, persistent chat history, PDF uploads, syllabus databases or payment features.
- Avoid entering private student records or confidential college information.
- AI-generated notes, answers and references can be inaccurate. Verify important material against your syllabus, textbooks and faculty guidance.

## Official references

- OpenAI API documentation: https://developers.openai.com/api/docs
- OpenAI Responses API: https://developers.openai.com/api/docs/guides/migrate-to-responses
- Render documentation: https://render.com/docs
- GitHub documentation: https://docs.github.com
