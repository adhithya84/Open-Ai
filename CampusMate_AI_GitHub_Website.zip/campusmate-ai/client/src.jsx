import React, { useState, useEffect } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const tools = [
  { id: "tutor", icon: "✦", title: "AI Study Tutor", desc: "Ask questions and understand difficult topics." },
  { id: "notes", icon: "▤", title: "Smart Notes", desc: "Convert long material into clear revision notes." },
  { id: "quiz", icon: "☷", title: "Practice Quiz", desc: "Generate practice questions with answers." },
  { id: "planner", icon: "◷", title: "Exam Planner", desc: "Build a balanced study timetable." },
  { id: "explain", icon: "◎", title: "Explain a Concept", desc: "Learn step by step with examples." },
  { id: "web", icon: "⌕", title: "Research Assistant", desc: "Explore a topic using web search." }
];

function App() {
  const [task, setTask] = useState("tutor");
  const [prompt, setPrompt] = useState("");
  const [subject, setSubject] = useState("");
  const [level, setLevel] = useState("College");
  const [useWeb, setUseWeb] = useState(false);
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [apiStatus, setApiStatus] = useState("Checking connection…");

  useEffect(() => {
    fetch("/api/health").then(r => r.json()).then(d => {
      setApiStatus(d.configured ? `Connected · ${d.model}` : "API key required");
    }).catch(() => setApiStatus("Start the local server to connect"));
  }, []);

  const activeTool = tools.find(t => t.id === task) || tools[0];
  const examples = {
    tutor: "Explain the difference between shares and debentures with a simple example.",
    notes: "Paste your chapter or class material here. Make concise exam revision notes with key terms.",
    quiz: "Create 10 practice questions on principles of management for a first-year commerce student.",
    planner: "I have 4 subjects and 14 days before exams. I can study 3 hours each day. Create a balanced plan.",
    explain: "Explain the concept of opportunity cost with a college-level example.",
    web: "Research the latest developments in digital payments in India. Include reliable sources."
  };

  async function submit(e) {
    e?.preventDefault();
    if (!prompt.trim()) { setError("Enter a question or study material first."); return; }
    setLoading(true); setError(""); setAnswer("");
    try {
      const response = await fetch("/api/ask", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ task, prompt, subject, level, useWeb: useWeb || task === "web" })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Request failed.");
      setAnswer(data.answer);
    } catch (err) { setError(err.message || "Unable to connect."); }
    finally { setLoading(false); }
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">C</div><div><b>CampusMate</b><span>AI LEARNING SPACE</span></div></div>
      <div className="side-label">WORKSPACE</div>
      <button className="nav-item active"><span>⌂</span> Dashboard</button>
      <div className="side-label tools-label">STUDY TOOLS</div>
      {tools.map(t => <button key={t.id} onClick={() => {setTask(t.id);setAnswer("");setError("");}} className={`nav-item ${task===t.id?"selected":""}`}><span>{t.icon}</span>{t.title}</button>)}
      <div className="sidebar-bottom"><div className="mini-orb">✧</div><b>Make learning count.</b><p>Understand more. Prepare smarter. Grow every day.</p></div>
    </aside>
    <main className="main">
      <header className="topbar"><div className="mobile-brand">CampusMate <span>AI</span></div><div className="top-status"><i className={apiStatus.startsWith("Connected")?"green":""}></i>{apiStatus}</div><div className="avatar">S</div></header>
      <section className="welcome">
        <div className="eyebrow">YOUR PERSONAL LEARNING COMPANION</div>
        <h1>Study smarter.<br/><em>Achieve more.</em></h1>
        <p>One space for your questions, notes, practice and exam preparation.</p>
      </section>
      <section className="tool-grid">
        {tools.map(t => <button key={t.id} className={`tool-card ${task===t.id?"chosen":""}`} onClick={() => {setTask(t.id);setAnswer("");setError("");}}>
          <div className="tool-icon">{t.icon}</div><div className="tool-title">{t.title}</div><div className="tool-desc">{t.desc}</div><div className="arrow">↗</div>
        </button>)}
      </section>
      <section className="workspace">
        <div className="workspace-head"><div><div className="eyebrow">STUDY WORKSPACE</div><h2>{activeTool.title}</h2><p>{activeTool.desc}</p></div><span className="live-badge">● AI POWERED</span></div>
        <form onSubmit={submit}>
          <div className="form-row">
            <label>SUBJECT <input value={subject} onChange={e=>setSubject(e.target.value)} placeholder="e.g. Accountancy, Economics, Computer Science"/></label>
            <label>STUDENT LEVEL <select value={level} onChange={e=>setLevel(e.target.value)}><option>College</option><option>School</option><option>Undergraduate</option><option>Postgraduate</option></select></label>
          </div>
          <label className="prompt-label">WHAT WOULD YOU LIKE TO WORK ON?</label>
          <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder={examples[task]} rows="5"/>
          <div className="form-footer"><label className="check"><input type="checkbox" checked={useWeb} onChange={e=>setUseWeb(e.target.checked)}/> Use web search for current information</label><button className="submit" disabled={loading}>{loading ? "Working…" : "Generate answer  →"}</button></div>
        </form>
        {error && <div className="error">{error}</div>}
        {loading && <div className="loading"><div className="spinner"></div><span>Preparing your study response…</span></div>}
        {answer && <div className="answer"><div className="answer-head"><b>✦ Your study response</b><button onClick={()=>navigator.clipboard?.writeText(answer)}>Copy</button></div><div className="answer-body">{answer}</div></div>}
      </section>
      <footer>CampusMate AI <span>·</span> Learn with curiosity. Prepare with confidence.</footer>
    </main>
  </div>;
}

createRoot(document.getElementById("root")).render(<App />);