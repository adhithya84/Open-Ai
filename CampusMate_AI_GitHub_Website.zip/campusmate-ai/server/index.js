import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";
import OpenAI from "openai";

const app = express();
app.use(cors());
app.use(express.json({ limit: "1mb" }));

const port = process.env.PORT || 3001;
const model = process.env.OPENAI_MODEL || "gpt-4.1-mini";

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY), model });
});

const taskInstructions = {
  tutor: "Teach clearly like a patient college tutor. Start with a simple explanation, then give a practical example, and finish with a short recap. Ask a check-your-understanding question when useful.",
  notes: "Turn the supplied material into well-organised study notes. Keep key definitions, headings, formulas and examples. Use simple student-friendly language. Do not invent facts missing from the source.",
  quiz: "Create a practice quiz from the supplied topic or material. Include a mix of multiple-choice and short-answer questions, then provide an answer key with brief explanations at the end. Clearly label it as practice, not an official exam.",
  planner: "Create a realistic exam study plan from the student's subjects, available time and exam dates. Include breaks, revision sessions and practice tests. Do not recommend unhealthy all-night study.",
  explain: "Explain the concept step by step in accessible language. Define difficult terms and include one relatable example.",
  web: "Answer the student's question using web search when appropriate. Prioritise reliable educational and official sources. Clearly separate verified facts from uncertainty and include source names or links when available."
};

app.post("/api/ask", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "API key missing. Add OPENAI_API_KEY to your .env file and restart the app." });
    }
    const { task = "tutor", prompt, subject = "", level = "College", useWeb = false } = req.body || {};
    if (typeof prompt !== "string" || !prompt.trim()) {
      return res.status(400).json({ error: "Please enter a topic, question or study material." });
    }
    if (prompt.length > 18000) {
      return res.status(400).json({ error: "Please keep your input under 18,000 characters." });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const instructions = [
      "You are CampusMate AI, a supportive educational assistant for college students.",
      "Help students learn; do not simply encourage copying. Explain reasoning and show steps for learning.",
      "Be accurate. If unsure, say so. Never fabricate citations, textbook page numbers, exam dates or official syllabus details.",
      "For exam preparation, create practice material and explain answers. Do not claim questions will appear in a real exam.",
      "Use readable headings and concise bullet points. Match the student's language if they request it.",
      `Student level: ${level}. Subject: ${subject || "Not specified"}.`,
      taskInstructions[task] || taskInstructions.tutor
    ].join("\n\n");

    const params = { model, instructions, input: prompt };
    if (useWeb || task === "web") params.tools = [{ type: "web_search" }];
    const response = await client.responses.create(params);
    res.json({ answer: response.output_text || "I couldn't generate a response. Please try again." });
  } catch (error) {
    console.error("CampusMate API error:", error?.message || error);
    const message = error?.status === 401
      ? "The API key was rejected. Check the key in your .env file."
      : error?.status === 429
      ? "The API rate limit or available balance was reached. Check your API account."
      : "Something went wrong while contacting the AI service. Please try again.";
    res.status(500).json({ error: message });
  }
});

// Serve the built React website in production (for Render or another Node host).
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distPath = path.resolve(__dirname, "../dist");
app.use(express.static(distPath));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(distPath, "index.html"), (err) => {
    if (err) next();
  });
});

app.listen(port, () => console.log(`CampusMate server running on port ${port}`));